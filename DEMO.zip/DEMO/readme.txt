1 after login Main page still displays login button next to the advanced rather display the first letter of username in circle(update this in the main page) eg; admin= a
2 rather than storing in the local storage get the user ID From the login.json file and if the username and password is admin's display the admin dashboard set username: admin password: admin123 as admin after login using this credentials there is no displaying in the admin dashboard of advanced.html(update advanced.html)
don't alter anything from the register.html and login.html just passing the credential to the main so that i don't have to login again use css html and javascript only only change necessary part or highlight the code so I can copy and paste it to the main folder of my project

and after admin login make the admin dashboard buttons functional not just for display






advanced.html      admin dashboard     
main.html          login button
login.json register.html login.html
