import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import ShopFinder from './components/ShopFinder';
import Login from './components/Login';
import Register from './components/Register';
import Advanced from './components/Advanced';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <nav className="bg-white shadow-lg p-4">
          <div className="container mx-auto flex justify-between items-center">
            <Link to="/" className="text-2xl font-bold text-blue-600">ShopFinder</Link>
            <div className="space-x-4">
              <Link to="/advanced" className="text-gray-600 hover:text-blue-600">Advanced</Link>
              <Link to="/login" className="text-gray-600 hover:text-blue-600">Login</Link>
              <Link to="/register" className="text-gray-600 hover:text-blue-600">Register</Link>
            </div>
          </div>
        </nav>

        <Routes>
          <Route path="/" element={<ShopFinder />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/advanced" element={<Advanced />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;