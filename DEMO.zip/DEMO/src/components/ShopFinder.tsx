import React, { useEffect, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface Shop {
  name: string;
  category: string;
  latitude: number;
  longitude: number;
  rating: number;
  premium: boolean;
  distance_km: number;
}

const presetShops: Shop[] = [
  {
    name: "Dembel City Center",
    category: "Clothing",
    latitude: 9.005411558649147,
    longitude: 38.767375136234,
    rating: 4.5,
    premium: true,
    distance_km: 1.2
  },
  {
    name: "Friendship City Center",
    category: "Mall",
    latitude: 8.990296814288943,
    longitude: 38.78606833782132,
    rating: 4.8,
    premium: false,
    distance_km: 0.8
  },
  {
    name: "Centery Mall",
    category: "Cinema",
    latitude: 9.01976695073015,
    longitude: 38.81381316439278,
    rating: 4.2,
    premium: false,
    distance_km: 5
  },
  {
    name: "Shoa Supermarket",
    category: "Supermarket",
    latitude: 8.957756153636755,
    longitude: 38.72633646439691,
    rating: 4.6,
    premium: true,
    distance_km: 3.0
  },
  {
    name: "Salem's Ethiopia",
    category: "Coffee",
    latitude: 8.993865726279626,
    longitude: 38.79247819323031,
    rating: 4.6,
    premium: true,
    distance_km: 2.0
  }
];

function ShopFinder() {
  const [map, setMap] = useState<L.Map | null>(null);
  const [markers, setMarkers] = useState<L.Marker[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [radius, setRadius] = useState(5);
  const [isPremiumOnly, setIsPremiumOnly] = useState(false);
  const [sortBy, setSortBy] = useState<'distance' | 'rating'>('distance');

  useEffect(() => {
    const mapInstance = L.map('map').setView([9.005411558649147, 38.767375136234], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(mapInstance);
    setMap(mapInstance);

    return () => {
      mapInstance.remove();
    };
  }, []);

  const filterAndSortShops = () => {
    let filtered = presetShops.filter(shop => {
      const matchesSearch = shop.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = !selectedCategory || shop.category === selectedCategory;
      const withinRadius = shop.distance_km <= radius;
      const meetsPremium = !isPremiumOnly || shop.premium;
      return matchesSearch && matchesCategory && withinRadius && meetsPremium;
    });

    return filtered.sort((a, b) => {
      if (sortBy === 'rating') {
        return b.rating - a.rating;
      }
      return a.distance_km - b.distance_km;
    });
  };

  useEffect(() => {
    if (!map) return;

    // Clear existing markers
    markers.forEach(marker => marker.remove());

    const filteredShops = filterAndSortShops();
    const newMarkers = filteredShops.map(shop => {
      const marker = L.marker([shop.latitude, shop.longitude])
        .bindPopup(`
          <b>${shop.name}</b><br>
          Category: ${shop.category}<br>
          Rating: ${shop.rating} ⭐
        `)
        .addTo(map);
      return marker;
    });

    setMarkers(newMarkers);

    if (newMarkers.length > 0) {
      const group = L.featureGroup(newMarkers);
      map.fitBounds(group.getBounds());
    }
  }, [map, searchQuery, selectedCategory, radius, isPremiumOnly, sortBy]);

  return (
    <div className="container mx-auto p-8">
      <div className="bg-white p-6 rounded-lg shadow-lg mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="text"
            placeholder="Search shops..."
            className="w-full px-4 py-2 border rounded-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <select
            className="w-full px-4 py-2 border rounded-lg"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            <option value="">All Categories</option>
            <option value="Clothing">Clothing</option>
            <option value="Mall">Mall</option>
            <option value="Cinema">Cinema</option>
            <option value="Supermarket">Supermarket</option>
            <option value="Coffee">Coffee</option>
          </select>
          <div>
            <input
              type="range"
              min="1"
              max="20"
              value={radius}
              onChange={(e) => setRadius(Number(e.target.value))}
              className="w-full"
            />
            <div className="text-center mt-2">
              Distance: {radius} km
            </div>
          </div>
        </div>

        <div className="mt-4 flex justify-end space-x-4">
          <button
            onClick={() => setSortBy('distance')}
            className={`px-4 py-2 rounded-lg ${
              sortBy === 'distance' ? 'bg-blue-500 text-white' : 'bg-gray-200'
            }`}
          >
            Sort by Distance
          </button>
          <button
            onClick={() => setSortBy('rating')}
            className={`px-4 py-2 rounded-lg ${
              sortBy === 'rating' ? 'bg-blue-500 text-white' : 'bg-gray-200'
            }`}
          >
            Sort by Rating
          </button>
          <button
            onClick={() => setIsPremiumOnly(!isPremiumOnly)}
            className={`px-4 py-2 rounded-lg ${
              isPremiumOnly ? 'bg-blue-500 text-white' : 'bg-gray-200'
            }`}
          >
            Premium Only
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-lg">
          <h2 className="text-xl font-semibold mb-4">Nearby Shops</h2>
          <div className="space-y-4">
            {filterAndSortShops().map((shop, index) => (
              <div
                key={index}
                className="border p-4 rounded-lg hover:bg-gray-50 cursor-pointer"
                onClick={() => {
                  map?.setView([shop.latitude, shop.longitude], 15);
                }}
              >
                <h3 className="font-semibold">{shop.name}</h3>
                <p className="text-sm text-gray-600">Category: {shop.category}</p>
                <p className="text-sm text-gray-600">
                  Distance: {shop.distance_km.toFixed(2)} km
                </p>
                <p className="text-sm text-gray-600">Rating: {shop.rating} ⭐</p>
                {shop.premium && (
                  <span className="text-xs bg-yellow-200 px-2 py-1 rounded">
                    Premium
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg">
          <div id="map" className="h-[600px]"></div>
        </div>
      </div>
    </div>
  );
}

export default ShopFinder;